package com.ad.messageservice.repository;

import com.ad.messageservice.model.Message;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {
    List<Message> findBySenderUserId(Long senderUserId);
    List<Message> findByReceiverUserId(Long receiverUserId);
    List<Message> findByAdvertiseId(Long advertiseId);
}
