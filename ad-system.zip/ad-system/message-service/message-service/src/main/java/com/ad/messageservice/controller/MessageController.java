package com.ad.messageservice.controller;

import com.ad.messageservice.model.Message;
import com.ad.messageservice.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/messages")
public class MessageController {

    @Autowired
    private MessageService service;

    @PostMapping
    public Message send(@RequestBody Message message) {
        return service.sendMessage(message);
    }

    @GetMapping("/sender/{id}")
    public List<Message> getBySender(@PathVariable Long id) {
        return service.getMessagesBySender(id);
    }

    @GetMapping("/receiver/{id}")
    public List<Message> getByReceiver(@PathVariable Long id) {
        return service.getMessagesByReceiver(id);
    }

    @GetMapping("/ad/{id}")
    public List<Message> getByAd(@PathVariable Long id) {
        return service.getMessagesByAd(id);
    }
}
