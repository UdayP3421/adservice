package com.ad.adservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
