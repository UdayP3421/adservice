package com.ad.adservice.service;

import com.ad.adservice.model.Advertisement;
import com.ad.adservice.repository.AdvertisementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdvertisementService {

    @Autowired
    private AdvertisementRepository repository;

    public Advertisement postAd(Advertisement ad) {
        ad.setStatus("Pending");
        return repository.save(ad);
    }

    public List<Advertisement> getAllAds() {
        return repository.findAll();
    }

    public List<Advertisement> getAdsByUser(Long userId) {
        return repository.findByUserId(userId);
    }

    public List<Advertisement> getAdsByCategory(String category) {
        return repository.findByCategory(category);
    }

    public Optional<Advertisement> getAdById(Long id) {
        return repository.findById(id);
    }

    public Advertisement updateStatus(Long id, String status) {
        Advertisement ad = repository.findById(id).orElseThrow();
        ad.setStatus(status);
        return repository.save(ad);
    }

    public Advertisement updateAd(Long id, Advertisement updated) {
        Advertisement ad = repository.findById(id).orElseThrow();
        ad.setTitle(updated.getTitle());
        ad.setCategory(updated.getCategory());
        ad.setDescription(updated.getDescription());
        ad.setPrice(updated.getPrice());
        return repository.save(ad);
    }

    public void deleteAd(Long id) {
        repository.deleteById(id);
    }
}
