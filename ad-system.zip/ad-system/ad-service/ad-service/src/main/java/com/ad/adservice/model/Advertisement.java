package com.ad.adservice.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Advertisement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String category;
    private Double price;
    private String description;
    private String status;  // Pending / Approved / Rejected

    private Long userId;
}
