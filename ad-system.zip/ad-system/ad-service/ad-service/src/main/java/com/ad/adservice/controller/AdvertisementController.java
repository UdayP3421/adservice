package com.ad.adservice.controller;

import com.ad.adservice.model.Advertisement;
import com.ad.adservice.service.AdvertisementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ads")
public class AdvertisementController {

    @Autowired
    private AdvertisementService service;

    @PostMapping
    public Advertisement createAd(@RequestBody Advertisement ad) {
        return service.postAd(ad);
    }

    @GetMapping
    public List<Advertisement> getAll() {
        return service.getAllAds();
    }

    @GetMapping("/user/{userId}")
    public List<Advertisement> getByUser(@PathVariable Long userId) {
        return service.getAdsByUser(userId);
    }

    @GetMapping("/category/{category}")
    public List<Advertisement> getByCategory(@PathVariable String category) {
        return service.getAdsByCategory(category);
    }

    @PutMapping("/{id}")
    public Advertisement updateAd(@PathVariable Long id, @RequestBody Advertisement ad) {
        return service.updateAd(id, ad);
    }

    @PutMapping("/{id}/approve")
    public String approve(@PathVariable Long id) {
        service.updateStatus(id, "Approved");
        return "Advertisement approved";
    }

    @PutMapping("/{id}/reject")
    public String reject(@PathVariable Long id) {
        service.updateStatus(id, "Rejected");
        return "Advertisement rejected";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        service.deleteAd(id);
        return "Advertisement deleted";
    }
}
