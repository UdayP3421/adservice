package com.ad.authservice.client;

import com.ad.authservice.model.UserDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "user-service")
public interface UserClient {

    @PostMapping("/users/register")
    String register(@RequestBody UserDTO user);

    @GetMapping("/users/username/{username}")
    UserDTO getUserByUsername(@PathVariable String username);
}
