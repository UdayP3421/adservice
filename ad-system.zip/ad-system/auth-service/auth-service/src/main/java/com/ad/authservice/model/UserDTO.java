package com.ad.authservice.model;

import lombok.Data;

@Data
public class UserDTO {
    private String username;
    private String password;
    private String email;
    private String contactno;
    private String address;
    private String role;
}
