package com.ad.authservice.controller;

import com.ad.authservice.client.UserClient;
import com.ad.authservice.model.LoginRequest;
import com.ad.authservice.model.UserDTO;
import com.ad.authservice.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserClient userClient;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/register")
    public String register(@RequestBody UserDTO user) {
        return userClient.register(user);
    }

    @PostMapping("/login")
    public String login(@RequestBody LoginRequest request) {
        UserDTO user = userClient.getUserByUsername(request.getUsername());
        if (user != null && user.getPassword().equals(request.getPassword())) {
            return jwtUtil.generateToken(user.getUsername());
        }
        return "Invalid Credentials";
    }
}
