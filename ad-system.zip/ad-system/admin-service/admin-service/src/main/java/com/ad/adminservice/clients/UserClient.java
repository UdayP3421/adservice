package com.ad.adminservice.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@FeignClient(name = "user-service")
public interface UserClient {
    @GetMapping("/users")
    List<Map<String, Object>> getAllUsers();

    @GetMapping("/users/{id}")
    Map<String, Object> getUserById(@PathVariable Long id);

    @DeleteMapping("/users/{id}")
    void deleteUser(@PathVariable Long id);
}

