package com.ad.adminservice.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import java.util.List;
import java.util.Map;

@FeignClient(name = "ad-service")
public interface AdvertisementClient {
    @GetMapping("/ads")
    List<Map<String, Object>> getAllAds();

    @PutMapping("/ads/{id}/approve")
    String approveAd(@PathVariable Long id);

    @PutMapping("/ads/{id}/reject")
    String rejectAd(@PathVariable Long id);
}
