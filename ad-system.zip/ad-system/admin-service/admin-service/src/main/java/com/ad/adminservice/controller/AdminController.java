package com.ad.adminservice.controller;

import com.ad.adminservice.clients.AdvertisementClient;
import com.ad.adminservice.clients.UserClient;
import com.ad.adminservice.model.Category;
import com.ad.adminservice.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private UserClient userClient;

    @Autowired
    private AdvertisementClient advertisementClient;

    @PostMapping("/category")
    public Category addCategory(@RequestBody Category category) {
        return adminService.addCategory(category);
    }

    @GetMapping("/users")
    public List<Map<String, Object>> viewAllUsers() {
        return userClient.getAllUsers();
    }

    @GetMapping("/users/{id}")
    public Map<String, Object> viewUserDetails(@PathVariable Long id) {
        return userClient.getUserById(id);
    }

    @DeleteMapping("/users/{id}")
    public String deleteUser(@PathVariable Long id) {
        userClient.deleteUser(id);
        return "User deleted";
    }

    @GetMapping("/ads")
    public List<Map<String, Object>> viewAllAds() {
        return advertisementClient.getAllAds();
    }

    @PutMapping("/ads/{id}/approve")
    public String approveAd(@PathVariable Long id) {
        return advertisementClient.approveAd(id);
    }

    @PutMapping("/ads/{id}/reject")
    public String rejectAd(@PathVariable Long id) {
        return advertisementClient.rejectAd(id);
    }
}
